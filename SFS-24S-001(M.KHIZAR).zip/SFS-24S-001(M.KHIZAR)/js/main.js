/* =====================================================
   PET CARE - JAVASCRIPT
   Each block below does one small job.
   ===================================================== */


/* 1. MOBILE MENU: click on ☰ to open or close the menu */
const burger = document.querySelector('.burger');
const menu = document.querySelector('.menu');

burger.onclick = function () {
  menu.classList.toggle('open');
};


/* 2. SCROLL ANIMATION: elements with class "rv" appear when you scroll to them */
const observer = new IntersectionObserver(function (items) {
  items.forEach(function (item) {
    if (item.isIntersecting) {
      item.target.classList.add('in');   // show it
      observer.unobserve(item.target);   // do it only once
    }
  });
}, { threshold: 0.12 });

document.querySelectorAll('.rv').forEach(function (el) {
  observer.observe(el);
});


/* 3. FAQ: click a question to open or close its answer */
document.querySelectorAll('.acc button').forEach(function (button) {
  button.onclick = function () {
    button.parentElement.classList.toggle('open');
  };
});


/* 4. BACK TO TOP BUTTON: shows after scrolling down 400px */
const topButton = document.getElementById('top');

window.addEventListener('scroll', function () {
  if (window.scrollY > 400) {
    topButton.style.display = 'block';
  } else {
    topButton.style.display = 'none';
  }
});

topButton.onclick = function () {
  window.scrollTo({ top: 0 });
};


/* 5. GALLERY: click a photo to see it big, click again to close */
const lightbox = document.getElementById('lb');
const bigImage = lightbox.querySelector('img');

document.querySelectorAll('.gal img').forEach(function (photo) {
  photo.onclick = function () {
    bigImage.src = photo.src;
    lightbox.classList.add('on');
  };
});

lightbox.onclick = function () {
  lightbox.classList.remove('on');
};


/* 6. CONTACT FORM: shows a thank-you message (does not send real email) */
document.querySelectorAll('form').forEach(function (form) {
  form.onsubmit = function (event) {
    event.preventDefault();   // stops page from reloading
    alert('Thank you! Your message has been received. 🐾');
    form.reset();             // clears the form
  };
});
